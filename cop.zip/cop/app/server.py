#!/usr/bin/env python3
"""Bharat AI - local server (Python standard library only).

Responsibilities
  * serves the UI from ./static to this PC and phones on the same private Wi-Fi (public IPs are refused)
  * starts / supervises the local inference runtime (KoboldCpp) as a child process
  * builds prompts, retrieves passages from the offline library (RAG), streams replies
  * keeps NO chat history on disk: the conversation lives only in the browser tab

All paths are resolved relative to this file, so the folder can live on any drive.
"""
import json
import os
import re
import subprocess
import sys
import threading
import time
import math
import http.client
import ipaddress
import socket
import ssl
import webbrowser
import ctypes
import shutil
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

APP_DIR = Path(__file__).resolve().parent
ROOT = APP_DIR.parent
STATIC = APP_DIR / "static"
LIB_FILE = APP_DIR / "library" / "articles.json"
CONFIG_FILE = ROOT / "config.json"
NUM_FILE = APP_DIR / "library" / "emergency_numbers.json"

DEFAULT_CONFIG = {
    "ui_port": 8765,
    "runtime_port": 5001,
    "runtime_exe": "runtime/koboldcpp.exe",
    "model_file": "model/Qwen3-4B-Q4_K_M.gguf",
    "context_length": 2048,
    "max_response_tokens": 512,
    "threads": 0,                 # 0 = let the runtime decide
    "use_gpu": False,             # CPU-first, per PRD 7.6
    "temperature": 0.6,
    "open_browser": True,
    "external_runtime": False,    # True = don't launch; use an already running KoboldCpp
    "host": "0.0.0.0",            # 0.0.0.0 = reachable from phones on the same Wi-Fi; 127.0.0.1 = this PC only
    "online_base_url": "",        # OpenAI-compatible base URL, e.g. https://example.com/v1
    "online_api_key": "",         # or set the CODECRAFT_API_KEY environment variable
    "online_default_model": "claude-opus-4.8",
    "online_models": ["claude-mythos-preview", "claude-opus-4.8"],   # used if the provider's /models call fails
}


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    try:
        cfg.update(json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
    except FileNotFoundError:
        pass
    except Exception as e:  # malformed config should not stop the library from working
        print("config.json unreadable, using defaults:", e)
    return cfg


CFG = load_config()


def online_key():
    return os.environ.get("CODECRAFT_API_KEY") or CFG.get("online_api_key") or ""


def online_base():
    b = (os.environ.get("CODECRAFT_BASE_URL") or CFG.get("online_base_url") or "https://www.codecraftapi.com/v1").strip().rstrip("/")
    if "codecraftapi.com" in b and "www.codecraftapi.com" not in b:
        b = b.replace("codecraftapi.com", "www.codecraftapi.com")
    return b


def online_conn(timeout=120):
    u = urlparse(online_base())
    if u.scheme not in ("http", "https") or not u.hostname:
        raise ValueError("The Online AI base URL is not set.")
    if u.scheme == "https":
        c = http.client.HTTPSConnection(u.hostname, u.port or 443, timeout=timeout, context=ssl.create_default_context())
    else:
        c = http.client.HTTPConnection(u.hostname, u.port or 80, timeout=timeout)
    return c, u.path.rstrip("/")

# ----------------------------------------------------------------------------
# Offline library + search (BM25, Devanagari aware, no dependencies)
# ----------------------------------------------------------------------------
TOKEN_RE = re.compile(r"[0-9A-Za-zऀ-ॿ]+")
STOP = set("""a an the and or of to in on at for is are was be it this that with as by from
how what do i my me we you your can should if when where who which about
hai hain ka ki ke ko se me mein par aur kya kaise karna kare karo""".split())


def tokenize(text):
    return [t for t in (w.lower() for w in TOKEN_RE.findall(text)) if t not in STOP and len(t) > 1]


class Library:
    def __init__(self, path):
        self.articles = []
        self.error = None
        self.chunks = []      # (article_idx, chunk_text, tokens)
        self.df = {}
        self.avgdl = 1.0
        self._load(path)

    def _load(self, path):
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            self.articles = data["articles"]
        except Exception as e:
            self.error = f"Knowledge library unavailable: {e}"
            return
        for i, a in enumerate(self.articles):
            a.setdefault("id", f"art-{i}")
            body = a.get("content", "")
            paras = [p.strip() for p in re.split(r"\n\s*\n", body) if p.strip()]
            # merge small paragraphs so each chunk has some context
            chunk, chunks = "", []
            for p in paras:
                if len(chunk) + len(p) < 700:
                    chunk = (chunk + "\n\n" + p).strip()
                else:
                    if chunk:
                        chunks.append(chunk)
                    chunk = p
            if chunk:
                chunks.append(chunk)
            head = " ".join([a.get("title", ""), a.get("category", ""), " ".join(a.get("keywords", []))])
            for c in chunks or [body]:
                toks = tokenize(head + " " + c) + tokenize(head)  # head terms weigh double
                self.chunks.append((i, c, toks))
        n = max(len(self.chunks), 1)
        for _, _, toks in self.chunks:
            for t in set(toks):
                self.df[t] = self.df.get(t, 0) + 1
        self.avgdl = sum(len(t) for _, _, t in self.chunks) / n

    def search(self, query, limit=3, lang=None):
        q = tokenize(query)
        if not q or not self.chunks:
            return []
        N = len(self.chunks)
        k1, b = 1.4, 0.75
        best = {}
        for ai, text, toks in self.chunks:
            if not toks:
                continue
            tf = {}
            for t in toks:
                tf[t] = tf.get(t, 0) + 1
            score = 0.0
            for t in q:
                if t in tf:
                    idf = math.log(1 + (N - self.df[t] + 0.5) / (self.df[t] + 0.5))
                    score += idf * tf[t] * (k1 + 1) / (tf[t] + k1 * (1 - b + b * len(toks) / self.avgdl))
            if score > 0 and (ai not in best or score > best[ai][0]):
                best[ai] = (score, text)
        ranked = sorted(best.items(), key=lambda kv: kv[1][0], reverse=True)[:limit]
        out = []
        for ai, (score, text) in ranked:
            a = self.articles[ai]
            out.append({"score": round(score, 2), "passage": text, **self.public(a, with_content=False)})
        return out

    @staticmethod
    def public(a, with_content=True):
        keys = ["id", "title", "category", "language", "region", "publisher", "source_url",
                "review_date", "next_review_date", "warnings", "status"]
        d = {k: a.get(k) for k in keys}
        if with_content:
            d["content"] = a.get("content", "")
        return d


LIB = Library(LIB_FILE)


class Numbers:
    """Offline directory of emergency phone numbers (app/library/emergency_numbers.json)."""
    def __init__(self, path):
        self.groups, self.items, self.error = [], [], None
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            self.groups = data["groups"]
            self.meta = {k: data.get(k) for k in ("country", "status", "note", "updated")}
        except Exception as e:
            self.error, self.meta = f"Emergency numbers unavailable: {e}", {}
        for g in self.groups:
            for it in g["items"]:
                it["group"] = g["group"]
                self.items.append(it)

    def search(self, query, limit=6):
        q = set(tokenize(query))
        scored = []
        for it in self.items:
            hay = set(tokenize(" ".join([it["name"], it.get("note", ""), it["group"], " ".join(it.get("keywords", []))])))
            sc = len(q & hay) + (3 if it["number"].replace(" ", "") in query else 0)
            if sc:
                scored.append((sc, it))
        scored.sort(key=lambda x: -x[0])
        hits = [it for _, it in scored[:limit]]
        if not hits:   # nothing matched: show the four numbers that matter most
            hits = [it for it in self.items if it["number"] in ("112", "100", "101", "102")]
        return hits


NUMS = Numbers(NUM_FILE)
MIN_RELEVANCE = 1.2   # below this we treat the library as having no answer

# ----------------------------------------------------------------------------
# Runtime supervision (KoboldCpp)
# ----------------------------------------------------------------------------
class Runtime:
    def __init__(self):
        self.proc = None
        self.state = "stopped"      # stopped | loading | ready | missing_model | missing_runtime | failed
        self.detail = ""
        self.log = []

    @property
    def port(self):
        return int(CFG["runtime_port"])

    def start(self):
        if CFG["external_runtime"]:
            self.state, self.detail = "loading", "Waiting for an external runtime on port %d" % self.port
            threading.Thread(target=self._wait_ready, daemon=True).start()
            return
        exe = (ROOT / CFG["runtime_exe"]).resolve()
        model = (ROOT / CFG["model_file"]).resolve()

        # Try common KoboldCpp executable names in the portable folder before failing.
        if not exe.is_file():
            candidates = [
                ROOT / "runtime" / "koboldcpp.exe",
                ROOT / "runtime" / "koboldcpp_nocuda.exe",
                ROOT / "runtime" / "koboldcpp_cu12.exe",
                ROOT / "koboldcpp.exe",
            ]
            found = next((p.resolve() for p in candidates if p.is_file()), None)
            if found:
                exe = found

        if not exe.is_file():
            # The user may already have started KoboldCpp manually.
            try:
                c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=1.5)
                c.request("GET", "/v1/models")
                response = c.getresponse()
                response.read()
                c.close()
                if response.status == 200:
                    self.state, self.detail = "ready", f"Using KoboldCpp already running on port {self.port}"
                    return
            except OSError:
                pass
            self.state, self.detail = "missing_runtime", (
                f"KoboldCpp executable is missing. Put koboldcpp.exe (or koboldcpp_nocuda.exe) "
                f"inside: {ROOT / 'runtime'} . Or start KoboldCpp manually on port {self.port} "
                f"and set external_runtime=true in config.json. The Emergency Help and Knowledge "
                f"Library work without the model."
            )
            return
        if not model.is_file():
            self.state, self.detail = "missing_model", f"Model file not found: {model}"
            return
        cmd = [str(exe), "--model", str(model), "--host", "127.0.0.1", "--port", str(self.port),
               "--contextsize", str(CFG["context_length"]), "--skiplauncher", "--quiet"]
        if CFG["threads"]:
            cmd += ["--threads", str(CFG["threads"])]
        if not CFG["use_gpu"]:
            cmd += ["--usecpu"]
        flags = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW
        try:
            self.proc = subprocess.Popen(cmd, cwd=str(exe.parent), stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, creationflags=flags)
        except OSError as e:
            self.state, self.detail = "failed", f"Could not start runtime: {e}"
            return
        self.state, self.detail = "loading", "Loading model..."
        threading.Thread(target=self._pump_log, daemon=True).start()
        threading.Thread(target=self._wait_ready, daemon=True).start()

    def _pump_log(self):
        for line in iter(self.proc.stdout.readline, b""):
            txt = line.decode("utf-8", "replace").rstrip()
            self.log.append(txt)
            self.log = self.log[-200:]
            low = txt.lower()
            if "out of memory" in low or "failed to allocate" in low or "bad_alloc" in low:
                self.state, self.detail = "insufficient_memory", \
                    "Not enough free RAM to load the model. Close other programs or lower the context length in config.json."
            elif "unknown model architecture" in low or "invalid magic" in low:
                self.state, self.detail = "incompatible_model", "The runtime cannot read this model file."

    def _wait_ready(self):
        deadline = time.time() + 600
        while time.time() < deadline:
            if self.proc and self.proc.poll() is not None:
                if self.state not in ("insufficient_memory", "incompatible_model"):
                    self.state = "failed"
                    self.detail = f"Runtime exited with code {self.proc.returncode}. See Settings > Troubleshooting."
                return
            try:
                c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=2)
                c.request("GET", "/v1/models")
                if c.getresponse().status == 200:
                    self.state, self.detail = "ready", "Model ready"
                    return
            except OSError:
                pass
            time.sleep(1.5)
        if self.state == "loading":
            self.state, self.detail = "failed", "Timed out while loading the model."

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(5)
            except subprocess.TimeoutExpired:
                self.proc.kill()


RT = Runtime()
GEN_LOCK = threading.Lock()   # one generation at a time (PRD 8.4)

LANG_NAMES = {"auto": None, "en": "English", "hi": "Hindi (Devanagari script)",
              "hinglish": "Hinglish (Hindi written in Roman letters, mixed with English)"}

BASE_SYSTEM = (
    "You are Bharat AI, a helpful offline assistant running locally on the user's computer. "
    "Be clear, concise and kind. Preserve technical terms and explain them simply. "
    "You are built on an existing open-weight model; do not claim to be trained by the Bharat AI project. "
    "If you are unsure, say so. Never invent sources. /no_think"
)


def build_messages(history, lang, passages, emergency_hint, numbers=None):
    sys_prompt = BASE_SYSTEM
    if LANG_NAMES.get(lang):
        sys_prompt += f" Reply in {LANG_NAMES[lang]}."
    else:
        sys_prompt += " Reply in the language the user writes in."
    if passages:
        ctx = "\n\n".join(f"[S{i+1}] {p['title']} ({p['publisher']})\n{p['passage']}" for i, p in enumerate(passages))
        sys_prompt += (
            "\n\nReference passages from the offline safety library are below. For safety questions, base your "
            "answer ONLY on them, keep steps short and numbered, and cite them as [S1], [S2]. If they do not "
            "answer the question, say that the library has no reviewed answer. Remind the user to call the local "
            "emergency number (112 in India) if there is immediate danger.\n\n" + ctx)
    elif emergency_hint:
        sys_prompt += (
            "\n\nThe user seems to ask about a safety or emergency situation, but the offline library has NO matching "
            "reviewed article. Say this clearly. Give only very general, cautious advice, do not present it as "
            "verified, and tell them to call 112 if anyone is in danger.")
    if numbers:
        sys_prompt += ("\n\nEMERGENCY NUMBERS (India). When relevant, quote these exactly and never invent a number:\n" +
                       "\n".join(f"- {n['name']}: {n['number']}" for n in numbers))
    # Rough context budget: ~3 chars per token, leave room for the reply
    budget = (CFG["context_length"] - CFG["max_response_tokens"]) * 3 - len(sys_prompt)
    kept, used = [], 0
    for m in reversed(history):
        used += len(m.get("content", ""))
        if used > budget and kept:
            break
        kept.append({"role": m["role"], "content": m["content"]})
    return [{"role": "system", "content": sys_prompt}] + list(reversed(kept))


EMERGENCY_WORDS = set("""earthquake flood fire burn bleeding bleed unconscious choking snake poison drowning
cpr emergency disaster cyclone heatstroke fracture water boil outage bhukamp baadh aag jalna khoon
भूकंप बाढ़ आग जलना खून आपातकाल सांप""".split())


def looks_like_emergency(text):
    return any(t in EMERGENCY_WORDS for t in TOKEN_RE.findall(text.lower()))


def strip_think(state, piece):
    """Remove <think>...</think> spans from a stream. state is a dict carried across chunks."""
    out = ""
    buf = state["buf"] + piece
    state["buf"] = ""
    while buf:
        if state["in"]:
            j = buf.find("</think>")
            if j == -1:
                state["buf"] = buf[-8:]
                return out
            buf, state["in"] = buf[j + 8:].lstrip("\n"), False
        else:
            j = buf.find("<think>")
            if j == -1:
                keep = 0
                for n in range(1, 7):
                    if buf.endswith("<think>"[:n]):
                        keep = n
                out += buf[:len(buf) - keep]
                state["buf"] = buf[len(buf) - keep:]
                return out
            out += buf[:j]
            buf, state["in"] = buf[j + 7:], True
    return out


# ----------------------------------------------------------------------------
# System Metrics & Bharat Pilot (PC Automation)
# ----------------------------------------------------------------------------
class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_uint32),
        ("dwMemoryLoad", ctypes.c_uint32),
        ("ullTotalPhys", ctypes.c_uint64),
        ("ullAvailPhys", ctypes.c_uint64),
        ("ullTotalPageFile", ctypes.c_uint64),
        ("ullAvailPageFile", ctypes.c_uint64),
        ("ullTotalVirtual", ctypes.c_uint64),
        ("ullAvailVirtual", ctypes.c_uint64),
        ("ullAvailExtendedVirtual", ctypes.c_uint64)
    ]

_last_cpu_times = None

def get_system_metrics():
    global _last_cpu_times
    ram_pct = 38
    total_gb = 8.0
    try:
        m = MEMORYSTATUSEX()
        m.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
            ram_pct = int(m.dwMemoryLoad)
            total_gb = round(m.ullTotalPhys / (1024**3), 1)
    except Exception:
        pass

    cpu_pct = 12
    try:
        idle = ctypes.c_uint64()
        kern = ctypes.c_uint64()
        usr = ctypes.c_uint64()
        if ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kern), ctypes.byref(usr)):
            now_times = (idle.value, kern.value, usr.value)
            if _last_cpu_times:
                idle_d = now_times[0] - _last_cpu_times[0]
                total_d = (now_times[1] - _last_cpu_times[1]) + (now_times[2] - _last_cpu_times[2])
                if total_d > 0:
                    cpu_pct = max(0, min(100, int(100 * (1.0 - (idle_d / total_d)))))
            _last_cpu_times = now_times
    except Exception:
        pass

    return {
        "ram_pct": cpu_pct if ram_pct == 0 else ram_pct,
        "cpu_pct": cpu_pct,
        "total_ram_gb": total_gb,
        "os": "Windows"
    }

def pilot_execute(action, target=""):
    action = str(action or "").lower().strip()
    target = str(target or "").lower().strip()

    if action in ("open_app", "app"):
        if "chrome" in target:
            webbrowser.open("https://www.google.com")
            return {"ok": True, "message": "Opened Google Chrome"}
        elif "vscode" in target or "code" in target:
            subprocess.Popen("code", shell=True)
            return {"ok": True, "message": "Opened Visual Studio Code"}
        elif "calc" in target or "calculator" in target:
            subprocess.Popen("calc.exe", shell=True)
            return {"ok": True, "message": "Opened Calculator"}
        elif "notepad" in target:
            subprocess.Popen("notepad.exe", shell=True)
            return {"ok": True, "message": "Opened Notepad"}
        elif "explorer" in target or "files" in target:
            subprocess.Popen("explorer.exe", shell=True)
            return {"ok": True, "message": "Opened File Explorer"}
        elif "youtube" in target:
            webbrowser.open("https://www.youtube.com")
            return {"ok": True, "message": "Opened YouTube in browser"}
        elif "whatsapp" in target:
            webbrowser.open("https://web.whatsapp.com")
            return {"ok": True, "message": "Opened WhatsApp Web"}
        elif "settings" in target:
            subprocess.Popen("explorer.exe ms-settings:", shell=True)
            return {"ok": True, "message": "Opened Windows Settings"}
        elif "taskmgr" in target or "task manager" in target or "control" in target:
            subprocess.Popen("taskmgr.exe", shell=True)
            return {"ok": True, "message": "Opened Task Manager"}
        elif "cmd" in target or "terminal" in target:
            subprocess.Popen("cmd.exe", shell=True)
            return {"ok": True, "message": "Opened Command Prompt"}
        else:
            return {"ok": False, "message": f"App '{target}' not recognized."}

    elif action == "screenshot":
        subprocess.Popen("explorer.exe ms-screenclip:", shell=True)
        return {"ok": True, "message": "Snipping Tool activated"}

    elif action == "search_web":
        q = urllib.parse.quote_plus(target or "Bharat AI")
        webbrowser.open(f"https://www.google.com/search?q={q}")
        return {"ok": True, "message": f"Searching web for: {target}"}

    elif action == "system_control":
        subprocess.Popen("explorer.exe ms-settings:", shell=True)
        return {"ok": True, "message": "Opened Windows System Settings"}

    elif action == "find_file":
        hits = []
        search_dirs = [Path.home() / "Desktop", Path.home() / "Documents", ROOT]
        query = target.lower()
        for sdir in search_dirs:
            if sdir.exists():
                try:
                    for item in sdir.glob(f"*{query}*"):
                        if len(hits) < 15:
                            hits.append({"name": item.name, "path": str(item), "is_dir": item.is_dir()})
                except Exception:
                    pass
        return {"ok": True, "files": hits, "count": len(hits)}

    elif action == "shutdown":
        subprocess.Popen("rundll32.exe user32.dll,LockWorkStation", shell=True)
        return {"ok": True, "message": "Workstation locked"}

    return {"ok": False, "message": f"Unknown action: {action}"}

def parse_pilot_command(text):
    t = str(text or "").lower().strip()
    if "open chrome" in t and "youtube" in t:
        webbrowser.open("https://www.youtube.com")
        return {
            "handled": True,
            "steps": [
                "Opening Google Chrome",
                "Navigating to YouTube",
                "Done! YouTube is now open in Chrome."
            ],
            "card": {
                "title": "YouTube",
                "url": "https://www.youtube.com",
                "icon": "youtube",
                "action_label": "Open in Browser"
            }
        }
    elif "open youtube" in t or "play youtube" in t:
        webbrowser.open("https://www.youtube.com")
        return {
            "handled": True,
            "steps": [
                "Launching browser",
                "Loading YouTube",
                "Done! YouTube is ready."
            ],
            "card": {
                "title": "YouTube",
                "url": "https://www.youtube.com",
                "icon": "youtube",
                "action_label": "Open in Browser"
            }
        }
    elif "open chrome" in t or "launch chrome" in t:
        webbrowser.open("https://www.google.com")
        return {
            "handled": True,
            "steps": [
                "Launching Google Chrome",
                "Done! Chrome opened."
            ],
            "card": {
                "title": "Google Chrome",
                "url": "https://www.google.com",
                "icon": "chrome",
                "action_label": "Open in Browser"
            }
        }
    elif "open notepad" in t or "launch notepad" in t:
        subprocess.Popen("notepad.exe", shell=True)
        return {
            "handled": True,
            "steps": [
                "Launching Notepad...",
                "Done! Notepad is open on your PC."
            ]
        }
    elif "open calculator" in t or ("calc" in t and len(t) < 15):
        subprocess.Popen("calc.exe", shell=True)
        return {
            "handled": True,
            "steps": [
                "Launching Windows Calculator...",
                "Done! Calculator is ready."
            ]
        }
    elif "open vs code" in t or "open code" in t:
        subprocess.Popen("code", shell=True)
        return {
            "handled": True,
            "steps": [
                "Starting Visual Studio Code...",
                "Done! VS Code workspace opened."
            ]
        }
    elif "take screenshot" in t or "screenshot" in t or "snip" in t:
        subprocess.Popen("explorer.exe ms-screenclip:", shell=True)
        return {
            "handled": True,
            "steps": [
                "Activating Screen Snipping Tool...",
                "Select area to capture screenshot."
            ]
        }
    elif "open settings" in t or "system control" in t:
        subprocess.Popen("explorer.exe ms-settings:", shell=True)
        return {
            "handled": True,
            "steps": [
                "Opening Windows System Settings...",
                "Done!"
            ]
        }
    elif ("file explorer" in t or "open files" in t or "open explorer" in t) and len(t) < 25:
        subprocess.Popen("explorer.exe", shell=True)
        return {
            "handled": True,
            "steps": [
                "Opening Windows File Explorer...",
                "Done!"
            ]
        }
    elif "system status" in t or "check cpu" in t or "check ram" in t:
        metrics = get_system_metrics()
        return {
            "handled": True,
            "steps": [
                "Scanning system hardware...",
                f"CPU Usage: {metrics['cpu_pct']}%",
                f"RAM Usage: {metrics['ram_pct']}% of {metrics['total_ram_gb']} GB",
                "All systems nominal and running smoothly."
            ]
        }
    return {"handled": False}


# ----------------------------------------------------------------------------
# HTTP handler
# ----------------------------------------------------------------------------
MIME = {".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css",
        ".svg": "image/svg+xml", ".json": "application/json", ".png": "image/png", ".ico": "image/x-icon"}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "BharatAI/0.1"

    def log_message(self, *a):  # keep the console quiet; never log prompts
        pass

    # -- helpers
    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _client_ip(self):
        try:
            return ipaddress.ip_address(self.client_address[0].split("%")[0])
        except ValueError:
            return None

    def _is_loopback(self):
        ip = self._client_ip()
        return bool(ip and (ip.is_loopback or getattr(ip, "ipv4_mapped", None) and ip.ipv4_mapped.is_loopback))

    def _local_only(self):
        """Allow this PC and devices on the same home/office network; refuse the public internet
        and DNS-rebinding hostnames (only IP literals, localhost and *.local are accepted)."""
        ip = self._client_ip()
        if ip is None:
            return False
        if getattr(ip, "ipv4_mapped", None):
            ip = ip.ipv4_mapped
        if not (ip.is_loopback or ip.is_private or ip.is_link_local):
            return False
        host = (self.headers.get("Host") or "").strip().lower()
        host = host[1:host.index("]")] if host.startswith("[") else host.rsplit(":", 1)[0]
        return bool(re.fullmatch(r"localhost|[\w-]+\.local|[0-9.]+|[0-9a-f:]+", host))

    # -- routes
    def do_GET(self):
        if not self._local_only():
            return self._json({"error": "forbidden"}, 403)
        u = urlparse(self.path)
        if u.path == "/api/status":
            metrics = get_system_metrics()
            return self._json({
                "state": RT.state, "detail": RT.detail,
                "library": {"ok": LIB.error is None, "error": LIB.error, "count": len(LIB.articles)},
                "config": {k: CFG[k] for k in ("context_length", "max_response_tokens", "use_gpu", "temperature")},
                "paths": ({"model": str((ROOT / CFG["model_file"]).resolve()),
                           "library": str(LIB_FILE.resolve())} if self._is_loopback() else {}),
                "log": RT.log[-40:] if self._is_loopback() else [],
                "local": self._is_loopback(),
                "lan_urls": lan_urls(),
                "online": {"configured": bool(online_base() and online_key()), "has_url": bool(online_base()),
                           "has_key": bool(online_key()), "host": urlparse(online_base()).hostname or "",
                           "key_hint": ("…" + online_key()[-4:]) if online_key() else "",
                           "default_model": CFG["online_default_model"]},
                "local_model": Path(CFG["model_file"]).stem,
                "emergency_numbers": {"ok": NUMS.error is None, "count": len(NUMS.items)},
                "metrics": metrics,
            })
        if u.path == "/api/pilot/status":
            return self._json({
                "metrics": get_system_metrics(),
                "runtime_state": RT.state,
                "online_configured": bool(online_base() and online_key()),
                "online_model": CFG["online_default_model"],
                "local_model": Path(CFG["model_file"]).stem
            })
        if u.path == "/api/online/models":
            return self._online_models()
        if u.path == "/api/emergency/numbers":
            return self._json({"groups": NUMS.groups, "meta": NUMS.meta, "error": NUMS.error})
        if u.path == "/api/emergency/ask":
            q = (parse_qs(u.query).get("q") or [""])[0].strip()[:500]
            arts = LIB.search(q, limit=2) if q else []
            top = arts[0]["score"] if arts else 0
            arts = [a for a in arts if a["score"] >= max(MIN_RELEVANCE, 0.5 * top)]
            return self._json({"numbers": NUMS.search(q) if q else [], "articles": arts})
        if u.path == "/api/library":
            q = parse_qs(u.query)
            query = (q.get("q") or [""])[0].strip()
            cat = (q.get("category") or [""])[0]
            lang = (q.get("language") or [""])[0]
            if query:
                hits = LIB.search(query, limit=20)
                items = [h for h in hits if (not cat or h["category"] == cat) and (not lang or h["language"] == lang)]
                for h in items:
                    h.pop("passage", None)
            else:
                items = [Library.public(a, with_content=False) for a in LIB.articles
                         if (not cat or a.get("category") == cat) and (not lang or a.get("language") == lang)]
            cats = sorted({a.get("category") for a in LIB.articles if a.get("category")})
            return self._json({"items": items, "categories": cats, "error": LIB.error})
        if u.path == "/api/article":
            aid = (parse_qs(u.query).get("id") or [""])[0]
            for a in LIB.articles:
                if a["id"] == aid:
                    cur = Library.public(a)
                    related = [x for x in LIB.articles if x.get("category") == a.get("category") and x["id"] != aid]
                    cur["related"] = [{"id": r["id"], "title": r["title"]} for r in related[:4]]
                    return self._json(cur)
            return self._json({"error": "not found"}, 404)
        # static files
        rel = "index.html" if u.path in ("/", "") else u.path.lstrip("/")
        f = (STATIC / rel).resolve()
        if STATIC.resolve() not in f.parents or not f.is_file():
            return self._json({"error": "not found"}, 404)
        data = f.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", MIME.get(f.suffix, "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if not self._local_only():
            return self._json({"error": "forbidden"}, 403)
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            return self._json({"error": "bad json"}, 400)
        if self.path == "/api/chat":
            return self._chat(body)
        if self.path == "/api/online/chat":
            return self._online_chat(body)
        if self.path == "/api/pilot/action":
            return self._json(pilot_execute(body.get("action", ""), body.get("target", "")))
        if self.path == "/api/pilot/command":
            return self._json(parse_pilot_command(body.get("command", "")))
        if self.path == "/api/online/config":
            if not self._is_loopback():
                return self._json({"error": "Change this on the PC that runs Bharat AI."}, 403)
            return self._save_online(body)
        if self.path == "/api/quit":
            if not self._is_loopback():
                return self._json({"error": "Quit from the PC that runs Bharat AI."}, 403)
            self._json({"ok": True})
            threading.Thread(target=shutdown, daemon=True).start()
            return
        self._json({"error": "not found"}, 404)

    def _sse(self, obj):
        self.wfile.write(b"data: " + json.dumps(obj, ensure_ascii=False).encode("utf-8") + b"\n\n")
        self.wfile.flush()

    # -- Online AI (OpenAI-compatible provider; the API key never leaves this server)
    def _online_models(self):
        fallback = list(CFG["online_models"])
        if not online_base() or not online_key():
            return self._json({"models": fallback, "configured": False, "error": "Online AI is not set up yet."})
        try:
            c, base = online_conn(10)
            c.request("GET", base + "/models", headers={"Authorization": "Bearer " + online_key(), "User-Agent": "OpenAI/Python"})
            r = c.getresponse()
            raw = r.read()
            c.close()
            if r.status != 200:
                raise OSError(f"HTTP {r.status}")
            ids = [m["id"] for m in json.loads(raw)["data"] if m.get("id")]
            pref = ["claude-opus-4.8", "claude-mythos-preview", "claude-opus-5.5", "gpt-5.5", "gemini-3.7-flash"]
            sorted_ids = [m for m in pref if m in ids] + [m for m in ids if m not in pref]
            return self._json({"models": sorted_ids or fallback, "configured": True, "error": None})
        except (OSError, ValueError, KeyError, TypeError) as e:
            return self._json({"models": fallback, "configured": True,
                               "error": f"Could not load the model list ({e}). Showing saved models."})

    def _save_online(self, body):
        url = str(body.get("base_url", "")).strip().rstrip("/")
        key = str(body.get("api_key", "")).strip()
        if url and not re.match(r"https?://[^\s/]+", url):
            return self._json({"error": "Base URL must start with http:// or https://"}, 400)
        try:
            raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8")) if CONFIG_FILE.exists() else {}
        except Exception:
            raw = {}
        if "base_url" in body:
            raw["online_base_url"] = CFG["online_base_url"] = url
        if key:
            raw["online_api_key"] = CFG["online_api_key"] = key
        CONFIG_FILE.write_text(json.dumps(raw, indent=2, ensure_ascii=False), encoding="utf-8")
        return self._json({"ok": True})

    def _online_chat(self, body):
        history = [m for m in body.get("messages", []) if m.get("role") in ("user", "assistant") and m.get("content")]
        if not history or history[-1]["role"] != "user":
            return self._json({"error": "no user message"}, 400)
        if body.get("pilot", True) and history:
            pilot_res = parse_pilot_command(history[-1]["content"])
            if pilot_res.get("handled"):
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Connection", "close")
                self.end_headers()
                self.close_connection = True
                self._sse({"pilot_action": pilot_res})
                self._sse({"done": True})
                return
        if not online_base() or not online_key():
            return self._json({"error": "online_not_configured",
                               "detail": "Online AI is not set up. Open About us > Online AI connection and add the base URL and key."}, 503)
        model = str(body.get("model") or CFG["online_default_model"])[:100]
        sys_prompt = ("You are Bharat AI, a highly capable and intelligent AI assistant made for India. "
                      "Explain things clearly and assist with programming, general knowledge, learning, and analysis. "
                      "Be polite, concise, and helpful. For any medical or safety emergency, tell the user to call 112.")
        lang = LANG_NAMES.get(body.get("language", "auto"))
        sys_prompt += f" Reply in {lang}." if lang else " Reply in the language the user writes in."
        payload = json.dumps({"model": model, "stream": True, "messages":
                              [{"role": "system", "content": sys_prompt}] + [{"role": m["role"], "content": m["content"]} for m in history[-30:]]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        up = None
        try:
            up, base = online_conn(120)
            up.request("POST", base + "/chat/completions", payload,
                       {"Content-Type": "application/json", "Authorization": "Bearer " + online_key(), "User-Agent": "OpenAI/Python"})
            resp = up.getresponse()
            if resp.status != 200:
                detail = resp.read(400).decode("utf-8", "replace")
                hint = {401: "The API key was rejected.", 403: "The API key was rejected.", 404: "Model or URL not found - check the base URL and model name.",
                        429: "Rate limit reached. Wait a moment and try again."}.get(resp.status, detail[:200])
                self._sse({"error": f"Online AI returned HTTP {resp.status}. {hint}"})
                return
            got = False
            while True:
                line = resp.readline()
                if not line:
                    break
                line = line.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    delta = json.loads(data)["choices"][0].get("delta", {}).get("content") or ""
                except (ValueError, KeyError, IndexError, TypeError):
                    continue
                if delta:
                    got = True
                    self._sse({"token": delta})
            if not got:
                self._sse({"error": "Online AI sent an empty reply. Try another model."})
            self._sse({"done": True})
        except (BrokenPipeError, ConnectionResetError):
            pass   # user pressed Stop; closing the upstream connection ends the stream
        except (OSError, ValueError) as e:
            try:
                self._sse({"error": f"Could not reach Online AI ({e}). Check your internet connection."})
            except OSError:
                pass
        finally:
            if up:
                up.close()

    def _chat(self, body):
        history = [m for m in body.get("messages", []) if m.get("role") in ("user", "assistant") and m.get("content")]
        if not history or history[-1]["role"] != "user":
            return self._json({"error": "no user message"}, 400)
        if body.get("pilot", True) and history:
            pilot_res = parse_pilot_command(history[-1]["content"])
            if pilot_res.get("handled"):
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Connection", "close")
                self.end_headers()
                self.close_connection = True
                self._sse({"pilot_action": pilot_res})
                self._sse({"done": True})
                return
        if RT.state != "ready":
            return self._json({"error": "model_not_ready", "state": RT.state, "detail": RT.detail}, 503)
        if not GEN_LOCK.acquire(timeout=5):   # waits so a just-stopped reply can finish releasing
            return self._json({"error": "busy", "detail": "A response is already being generated."}, 429)
        try:
            question = history[-1]["content"]
            hits = LIB.search(question, limit=2)
            top = hits[0]["score"] if hits else 0
            passages = [p for p in hits if p["score"] >= max(MIN_RELEVANCE, 0.5 * top)]
            msgs = build_messages(history, body.get("language", "auto"), passages, looks_like_emergency(question),
                                  numbers=NUMS.search(question, limit=5) if body.get("mode") == "emergency" else None)
            payload = json.dumps({
                "model": "local", "messages": msgs, "stream": True,
                "max_tokens": int(CFG["max_response_tokens"]), "temperature": float(CFG["temperature"]),
            }).encode("utf-8")

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            self._sse({"sources": [{k: p[k] for k in ("id", "title", "publisher", "source_url", "review_date", "status")}
                                   for p in passages], "emergency_no_source": bool(not passages and looks_like_emergency(question))})

            up = http.client.HTTPConnection("127.0.0.1", RT.port, timeout=300)
            try:
                up.request("POST", "/v1/chat/completions", payload, {"Content-Type": "application/json"})
                resp = up.getresponse()
                if resp.status != 200:
                    self._sse({"error": f"Runtime returned HTTP {resp.status}"})
                    return
                tstate = {"buf": "", "in": False}
                while True:
                    line = resp.readline()
                    if not line:
                        break
                    line = line.decode("utf-8", "replace").strip()
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        delta = json.loads(data)["choices"][0].get("delta", {}).get("content") or ""
                    except (ValueError, KeyError, IndexError):
                        continue
                    piece = strip_think(tstate, delta)
                    if piece:
                        self._sse({"token": piece})
                self._sse({"done": True})
            except (BrokenPipeError, ConnectionResetError):
                # user pressed Stop: closing the upstream connection aborts generation
                try:
                    c = http.client.HTTPConnection("127.0.0.1", RT.port, timeout=2)
                    c.request("POST", "/api/extra/abort", b"{}", {"Content-Type": "application/json"})
                    c.getresponse().read()
                except OSError:
                    pass
            except OSError as e:
                try:
                    self._sse({"error": f"Could not reach the local model: {e}"})
                except OSError:
                    pass
            finally:
                up.close()
        finally:
            GEN_LOCK.release()


SERVER = None


def lan_urls():
    """Addresses a phone on the same Wi-Fi can open."""
    if CFG["host"] in ("127.0.0.1", "localhost"):
        return []
    ips = set()
    try:   # no packet is sent; this just asks the OS which interface goes to the network
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sk:
            sk.connect(("10.255.255.255", 1))
            ips.add(sk.getsockname()[0])
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    ips = sorted((i for i in ips if not i.startswith(("127.", "169.254."))), key=lambda i: (not i.startswith("192.168."), i))
    return [f"http://{i}:{CFG['ui_port']}/" for i in ips]


def shutdown():
    time.sleep(0.2)
    RT.stop()
    if SERVER:
        SERVER.shutdown()


def safe_print(*args, **kwargs):
    try:
        print(*args, **kwargs)
    except Exception:
        clean = [str(a).encode("ascii", "replace").decode("ascii") for a in args]
        print(*clean, **kwargs)

def main():
    global SERVER
    RT.start()
    host = CFG["host"]
    SERVER = ThreadingHTTPServer((host, int(CFG["ui_port"])), Handler)
    SERVER.daemon_threads = True
    url = f"http://127.0.0.1:{CFG['ui_port']}/"
    safe_print("\n" + "=" * 66)
    safe_print("        [+]  BHARAT AI  -  BUILT FOR BHARAT  [+]")
    safe_print("      Offline * Private * Powerful * Macro UI Dashboard")
    safe_print("=" * 66)
    safe_print(f"  [PC]     On this Computer : {url}")
    if host not in ("127.0.0.1", "localhost"):
        lan = lan_urls()
        for u in lan:
            safe_print(f"  [Mobile] On your Mobile   : {u}  (connect to same Wi-Fi)")
        if lan:
            try:
                import qrcode
                q = qrcode.QRCode(border=1)
                q.add_data(lan[0])
                q.print_ascii(invert=True)
            except Exception:
                pass
            safe_print("  [*] Open the Mobile URL above on your phone's browser!")
            safe_print("  [*] If the phone cannot connect, allow Python through Windows Firewall.")
    safe_print("=" * 66)
    safe_print("  [>] Models: Online CodeCraft (Claude Opus 4.8 / Mythos) + Offline")
    safe_print("  [>] Pilot : Natural Language PC Control (Chrome, YouTube, Apps)")
    safe_print("  [>] SOS   : All India Emergency Numbers & Medical Guides active")
    safe_print("=" * 66)
    safe_print("  Close this window (or click Quit in app) to stop.\n")
    if CFG["open_browser"]:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        SERVER.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        RT.stop()


if __name__ == "__main__":
    main()
