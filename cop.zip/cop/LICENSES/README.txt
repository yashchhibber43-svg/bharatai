Add the license texts for every redistributed component before sharing this package:
 - KoboldCpp (AGPL-3.0)
 - Qwen3-4B model (check the license on the exact GGUF you bundle; Qwen3 is Apache-2.0)
 - Embedded Python (PSF License)
 - Any emergency articles (publisher permission / license)
