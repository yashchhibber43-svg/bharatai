"""Tiny fake OpenAI-style streaming server so the app can be tested without a model."""
import json, sys, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
class H(BaseHTTPRequestHandler):
    protocol_version="HTTP/1.1"
    def log_message(self,*a): pass
    def do_GET(self):
        b=b'{"data":[{"id":"mock"}]}'
        self.send_response(200);self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b)
    def do_POST(self):
        n=int(self.headers.get("Content-Length") or 0);body=json.loads(self.rfile.read(n) or b"{}")
        if self.path!="/v1/chat/completions":
            self.send_response(200);self.send_header("Content-Length","2");self.end_headers();self.wfile.write(b"{}");return
        open("/tmp/last_prompt.json","w").write(json.dumps(body))
        self.send_response(200);self.send_header("Content-Type","text/event-stream");self.send_header("Connection","close");self.end_headers()
        for t in ["<thi","nk>hidden</think>","Namaste! ","Drop, ","cover [S1]."]:
            self.wfile.write(("data: "+json.dumps({"choices":[{"delta":{"content":t}}]})+"\n\n").encode());self.wfile.flush();time.sleep(0.05)
        self.wfile.write(b"data: [DONE]\n\n");self.close_connection=True
ThreadingHTTPServer(("127.0.0.1",5001),H).serve_forever()
